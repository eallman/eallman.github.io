% How to plot a space curve in 3-dimensions, complete
% with animation

% Colons at end of lines suppress output to the console.  Use them.

% spacing between x and y values for plotting
stepSize = .02;
begT = -2*pi;
endT = 2*pi;

% define the space curve you want to plot
t=begT:stepSize:endT;
x = sin(2*t);
y = t.^2;
z = cos(2*t);

% set a fontsize for legibility
fs=24;


% Plot the curve all at once
plot3(x,y,z,'r','LineWidth',1)

pause

% put in axes
xMin = min(x)-1; xMax = max(x)+1;
yMin = min(y)-1; yMax = max(y)+1;
zMin = min(z)-1; zMax = max(z)+1;

curve = animatedline('LineWidth',2,'Color','b');
set(gca,'XLim',[xMin xMax],'YLim',[yMin yMax],'ZLim',[zMin zMax])

% label the axes
xlabel('X','FontSize',fs)
ylabel('Y','FontSize',fs)
zlabel('Z','FontSize',fs,'rotation',0)

% put in grid lines
grid on

% set the camera angle
view(145,30)

% Hold the current plot on.  That is, do not erase the current plot
% when making the next one.
hold on

for i=1:length(t)
  addpoints(curve,x(i),y(i),z(i));
  head = scatter3(x(i),y(i),z(i),'filled','MarkerFaceColor','b','MarkerEdgeColor','b');
  drawnow
  %     pause(0.1);
  % delete last marker at head of curve
  delete(head);
end

% keep last marker
head = scatter3(x(i),y(i),z(i),'filled','MarkerFaceColor','b','MarkerEdgeColor','b');
drawnow

