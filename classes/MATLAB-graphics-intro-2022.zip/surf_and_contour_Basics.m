% Good graphics for section 14.1 on surfaces and contour plots

% Basic surface plots


% surfaces and contours
example1 = 0;
% subplots containing surfaces and contours
example2 = 1;

if (example1)
  
  disp('Eg 1')
  
  [X1,Y1] = meshgrid(-10:0.5:10,-10:0.5:10);
  [X2,Y2] = meshgrid(-2:0.05:2,-2:0.05:2);
  [X3,Y3] = meshgrid(-5:0.1:5,-5:0.1:5);
  [X4,Y4] = meshgrid(-2:0.1:2,-2:0.1:2);
  Z1=2*X1.^2 + 5*Y1.^2;        % paraboloid
  Z2=exp(-2*X2.^2 -2*Y2.^2);   % Gaussian
  Z3=sin(X3.*Y3);              % egg crate
  Z4=(X4.^2-Y4.^2)./(X4.^2 + Y4.^2);    % who knows?
  str1='f(x,y) = 2x^2 + 5y^2';
  str2='f(x,y) = exp(-2x^2 -2y^2)';
  str3='f(x,y) = sin(xy)';
  str4='f(x,y) = (x^2 - y^2)/(x^2+y^2)';
  % Z=2*X.^2 - Y.^2;
  
  figure(1)
  clf
  for i=1:4
    if (i==1)
      X=X1; Y=Y1;
      Z = Z1;
      str = str1;
    end
    if (i==2)
      X=X2; Y=Y2;
      Z = Z2;
      str = str2;
    end
    if (i==3)
      X=X3; Y=Y3;
      Z = Z3;
      str = str3;
    end
    if (i==4)
      X=X4; Y=Y4;
      Z = Z4;
      str = str4;
    end
    
    subplot(1,2,1)
    contour(X,Y,Z,'ShowText','On','LineWidth',3)
    xlabel('X')
    ylabel('Y')
    xticklabels('')
    yticklabels('')
    axis square
    
    subplot(1,2,2)
    if (i==3)
      axis([-4 4 -4 4 -2 2])
      hold on
    end
    surf(X,Y,Z)
    xlabel('X')
    ylabel('Y')
    zlabel('Z')
    title(str,'FontSize',32)
    
    pause
  end
  
end

pause

if (example2)
  
  disp('Eg 2')
  
  stepSize=.1;
  [X,Y] = meshgrid(-5:stepSize:5,-5:stepSize:5);
  figure(2)
  clf
  f1=(X.^2 + 3*Y^2).*exp((-X.^2-Y.^2)/10);
  f2=sin(X) + sin(Y);
  f3=(3*sin(X).*sin(Y))./(.01+exp(-abs(X)));
  
  subplot(1,3,1)
  contour(X,Y,f3,'ShowText','On','LineWidth',2)
  subplot(1,3,2)
  contour(X,Y,f1,'ShowText','On','LineWidth',2)
  subplot(1,3,3)
  contour(X,Y,f2,'ShowText','On','LineWidth',2)
  
  figure(3)
  clf
  subplot(1,3,1)
  surf(X,Y,f2)
  subplot(1,3,2)
  surf(X,Y,f3)
  subplot(1,3,3)
  surf(X,Y,f1)
  
  xlabel('X')
  ylabel('Y')
  zlabel('Z')
  
end
