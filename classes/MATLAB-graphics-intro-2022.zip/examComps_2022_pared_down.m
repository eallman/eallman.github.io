% Graphics for exam and quiz problems so far this year

% Exam 2

lwd=2;
% lwdAxes=2;
fs=24;

doGradProb = 1;
doSurfAreaProb = 1;
doContourProb = 1;
doPolarPlot = 1;

% Good view values
%
% azimuth measured from -y-axis
%   view(134,13)

% This is the view familiar to students
% view(130,24)

if (doGradProb)

  % gradient problem

  xMin=-3; xMax=3;
  yMin=-3; yMax=3;
  stepSize=0.1;

  [X3,Y3] = meshgrid(xMin:stepSize:xMax,yMin:stepSize:yMax);
  Z3=4+exp(-(X3+2).^2 - 3*(Y3-1).^2);
  str3='f(x,y)';

  X=X3; Y=Y3;
  Z = Z3;
  str = str3;

  figure(1)
  clf

  % draw axes
  axis([xMin xMax yMin yMax]);
  plot([xMin,xMax],[0,0],'k')
  hold on
  plot([0,0],[yMin yMax],'k')


  contour(X,Y,Z,'ShowText','On','LineWidth',3)
  xlabel('X')
  ylabel('Y','rotation',0)
  % xticklabels('')
  % yticklabels('')
  grid on
  axis square

  xlabel('X','FontSize',fs)
  ylabel('Y','FontSize',fs)

  figure(2)
  clf

  surf(X,Y,Z)
  xlabel('X')
  ylabel('Y')
  zlabel('Z')
  title(str,'FontSize',32)

  figure(1)
end

if (doSurfAreaProb)

  figure(1)
  clf

  [X1,Y1] = meshgrid(-2:0.05:2,-pi:0.05:pi);
  Z1=1-X1.^2-Y1.^2;
  set(gca,'view',[  142.7015   37.9711])

  figure(1)
  surf(X1,Y1,Z1)
  xlabel('X')
  ylabel('Y')
  hold on
  Z2=0.*X1.*Y1+-2;
  surf(X1,Y1,Z2,'FaceColor',[0.9,0.2,0.9],'EdgeColor','none','FaceAlpha',0.6)

end

if (doContourProb)

  xRange=-2.6:.02:2.6;
  yRange=xRange;
  [xx,yy]=meshgrid(xRange,yRange);

  zz=peaks(xx,yy);
  zz=2*zz;
  figure(3)
  clf

  cc = [-16:2:14,15.5];
  [C,h]=contour(xx,yy,zz,cc,'LineWidth',lwd,'ShowText','On');
  clabel(C,h,'FontSize',18)
  xlabel('X','FontSize',fs)
  ylabel('Y','FontSize',fs,'rotation',0)

  set(gca,'YTick',[-2 -1 0 1 2],'XTick',[-2 -1 0 1 2])

  grid on
  set(gca,'BoxStyle','full','FontSize',18,'LineWidth',2);
  axis square

  hold on

  % circle of radius 1
  tt=0:.01:2*pi;
  xx=1*cos(tt); yy=1*sin(tt);
  plot(xx,yy,'k','LineWidth',4)
  %   plot(xx/2,yy/2,'k','LineWidth',4)

  title({'Contour plot of f(x,y)','Constraint g(x,y) = 0 in black.',' '},...
    'FontSize',18);

  % plot location of max
  plot(0,1.58,'.r','MarkerSize',40)
end

if (doPolarPlot)
  figure(1)
  clf
  % make a rectangular grid of r and theta,
  % then define x and y in the usual way
  rr = 0:.05:2;
  thth = (0:.05:1)*2*pi;
  [r th] = meshgrid(rr,thth);
  x = r.*cos(th);
  y = r.*sin(th);
  z = 1 - x.^2 - y.^2;
  surf(x,y,z)

  set(gca,'BoxStyle','full','FontSize',18,'LineWidth',2);
  set(gca,'FontSize',18,'LineWidth',2);
  axis square

  xlabel('X','FontSize',fs)
  ylabel('Y','FontSize',fs,'rotation',0)

  str='f(x,y) = 1 - x^2 - y^2';
  title(str,'FontSize',32)

  % azimuth measured from -y-axis
  view(134,13)
end

