% Some graphics created for exams and finals from last year

doProb1 = 0;
doFinal1 = 0;

% plotting surfaces in polar coordinates
doProb6 = 1;

if (doFinal1)
    
    xmin = -3;
    xmax = 4;
    xstep =0.01;
    
    ymin = xmin;
    ystep = xstep;
    ymax = xmax;
    
    x=xmin:xstep:xmax;
    y=ymin:ystep:ymax;
    
    [X,Y] = meshgrid(x,y);
    Z1 = (X-1).*(exp(Y-2) - 1);
    
    Z=Z1;
    % Z = sin(X).*cos(Y);
    % Z=Y.*sin(X.*Y)
    Z1=6*exp((-(X-3).^2-(Y-1).^2)/1);
    Z4=8*exp((-(X-.5).^2-(Y-1.5).^2)/.4);
    
    Z2=-5*exp((-(X+1).^2-(Y+1).^2)/.4);
    Z3=sin(X);
    
    Z5=-3*exp((-(X-2).^2-(Y+1.5).^2)/1);
    Z6=4*exp((-(X-2).^2-(Y-2).^2)/1);
    Z7=4*exp((-(X+2).^2-(Y-2).^2)/1);
    Z=Z1+Z2+Z3+Z4+Z5+Z6+Z7;
    
    figure(1)
    clf

    surf(X,Y,Z)
    xlabel('x')
    ylabel('y')
    zlabel('z')
    view([46.1076368598932 31.3772418990203]);
    title('f(x,y)','FontSize',36);
    hold on
    surf(X,Y,Z)
    
    figure(2)
    clf
    % contour(X,Y,Z,-10:10,'ShowText','on','LineWidth',3)
    % for Z3
    
    %   cc = [0 1 3 3.2 3.3 3.5 4:4:24];
    %   cc = [-12:3:0 1 2 3 3.1 3.3 3.6 4 4.7 5 6 7 8:3:21];
    
    % plot specifice contour lines for values stored in cc
    cc = [ -8:2:-2 -1:0.5:1 1 2:9];
    [C,h]=contour(X,Y,Z,cc,'LineWidth',2)
    % alternatively plot 20 contour lines
    %   [C,h]=contour(X,Y,Z,20,'LineWidth',2)
    clabel(C,h,'FontSize',18)
    xlabel('X')
    ylabel('Y')
    set(get(gca,'ylabel'),'rotation',0)
    grid on
    set(gca,'BoxStyle','full','FontSize',18,'LineWidth',2);
    hold on
     
    % plot axes
    plot([xmin xmax],[0,0],'k','LineWidth',1)
    plot([0,0],[ymin,ymax],'k','LineWidth',1)
    
    title({'Contour plot of temperature T(x,y) in Celcius',' '},'FontSize',24)
    
    % plot some points for the question
    plot(1.01,2.3,'k.','MarkerSize',69)
    plot(-1,-1,'b.','MarkerSize',69)    
    
end

if (doProb1)
    % Problem 2nd derivative test
    xmin = -1.5;
    xmax = 2;
    xstep =0.05;
    
    ymin = xmin;
    ystep = xstep;
    ymax = xmax;
    
    x=xmin:xstep:xmax;
    y=ymin:ystep:ymax;
    
    [X,Y] = meshgrid(x,y);
    Z1= 5 + 2*X.^3 - 2*Y.^3 + 6*X.*Y;
    Z2=-2*sqrt(1-X.^2/9+Y.^2);
    Z3 = 25 - X.^2 - 4*Y.^2;
    Z=Z1;
    % Z = sin(X).*cos(Y);
    % Z=Y.*sin(X.*Y)
    % Z1=8*exp(-(X-1).^2-(Y+2).^2);
    % Z2=-5*exp(-(X+2).^2-(Y-1).^2);
    % Z3=sin(X);
    % Z4=10*exp((-(X-.5).^2-(Y-1.5).^2)/.5);
    % Z5=-3*exp((-(X-2).^2-(Y).^2)/.25);
    % Z=Z1+Z2+Z3+Z4+Z5;
    
    figure(1)
    clf
    % axis equal
    surf(X,Y,Z)
    xlabel('x')
    ylabel('y')
    zlabel('z')
    view([46.1076368598932 31.3772418990203]);
    title('f(x,y)');
    hold on
    surf(X,Y,Z)
    
    figure(2)
    clf
    % contour(X,Y,Z,-10:10,'ShowText','on','LineWidth',3)
    % for Z3
    
    cc = [0 1 3 3.2 3.3 3.5 4:4:24];
    cc = [-12:3:0 1 2 3 3.1 3.3 3.6 4 4.7 5 6 7 8:3:21];
    
    [C,h]=contour(X,Y,Z,cc,'LineWidth',2)
    % [C,h]=contour(X,Y,Z,'LineWidth',2)
    clabel(C,h,'FontSize',18)
    xlabel('X')
    ylabel('Y')
    set(get(gca,'ylabel'),'rotation',0)
    grid on
    % set(gca,'BoxStyle','full','FontSize',18,'Layer','top','LineWidth',2);
    set(gca,'BoxStyle','full','FontSize',18,'LineWidth',2);
    hold on
    %   plot(-3,2,'k.','MarkerSize',36,'LineWidth',5)
    % plot(1,-2,'k.','MarkerSize',36,'LineWidth',5)
    
    % plot axes
    %   plot([xmin xmax],[0,0],'k','LineWidth',1)
    %   plot([0,0],[ymin,ymax],'k','LineWidth',1)
    
end

if doProb6
    
    % The function on a polar grid
    [t,r] = meshgrid(linspace(0,2*pi,361),linspace(1,2,101));
    [x,y] = pol2cart(t,r);
    P = x.*y;
    
    % Define some angular and radial range vectors for example plots
    t1 = 2*pi;
    t2 = [0 2*pi];
    r1 = 4;
    r2 = [1,2];
    t3 = fliplr(t2);
    r3 = fliplr(r2);
    t4 = [30 35 45 60 90 135 200 270]*pi/180;
    r4 = [0.8:0.4:2.8 3:0.2:4];
    
    % Axis property cell array
    axprop = {'DataAspectRatio',[1,1,1],'View', [-12 38],...
        'Xlim', [-4.5 4.5],       'Ylim', [-4.5 4.5],...
        'XTick',[-4 -2 0 2 4],    'YTick',[-4 -2 0 2 4]};
    
    
    figure('color','white');
    polarplot3d(P,'plottype','surfn','angularrange',t2,...
        'radialrange',r2,'tickspacing',15,...
        'polardirection','cw','colordata',gradient(P.').');
    set(gca,axprop{:});
    
    figure('color','white');
    
    polarplot3d(P,'plottype','surfcn','angularrange',t2,'radialrange',r2,...
        'polargrid',{8,8},'tickspacing',15);
    set(gca,axprop{:});
    
end
